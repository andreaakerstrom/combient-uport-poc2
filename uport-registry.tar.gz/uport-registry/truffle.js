module.exports = {
  build: {
  },
  rpc: {
    host: "localhost",
    port: 8545
  }
};
